'use strict';
/**
 * Batería de pruebas del filtro (lib/flujo.js). Simula todos los escenarios.
 * Correr:  node test-flujo.js
 */
const { procesarFlujo } = require('./lib/flujo');
const { fetchPropiedades } = require('./lib/chat');

const flow = (zonas) => ({ tipo: 'flow', zonas });
const op = (id) => ({ tipo: 'opcion', id, texto: '' });
const txt = (t) => ({ tipo: 'texto', texto: t });

let PASS = 0, FAIL = 0;
function ok(cond, label) { if (cond) { PASS++; } else { FAIL++; console.log('   ❌ FALLA: ' + label); } }
function tipos(r) { return r.mensajes.map((m) => m.tipo).join(','); }
function texto1(r) { const m = r.mensajes.find((x) => x.texto); return m ? m.texto : ''; }

(async () => {
  const props = await fetchPropiedades();
  const P = (est, inp) => procesarFlujo(est, inp, props);

  // ---------- 1. Happy path completo (Palermo, 1 amb, hasta 800) ----------
  console.log('1) Happy path: Palermo 1amb hasta 800 -> visita -> despedida -> fin');
  {
    let r = P({}, txt('hola'));
    ok(r.estado.step === 'zona_flow' && r.mensajes.length === 2 && r.mensajes[0].tipo === 'texto' && /Te habla Tomás/.test(r.mensajes[0].texto) && r.mensajes[1].tipo === 'flow', '1.saludo en 2 mensajes (texto + flow)');
    r = P(r.estado, flow(['z_palermo']));
    ok(r.estado.step === 'ambientes', '1.ambientes');
    r = P(r.estado, op('amb_1'));
    ok(r.estado.step === 'tiempo', '1.tiempo');
    r = P(r.estado, op('t_ya'));
    ok(r.estado.step === 'presupuesto' && /podemos ofrecerte/.test(texto1(r)), '1.tiempo muestra opciones');
    ok(r.mensajes.some((m) => m.tipo === 'imagen_caption'), '1.tiempo manda fotos');
    ok(r.mensajes[r.mensajes.length - 1].tipo === 'lista', '1.pregunta presupuesto al final');
    r = P(r.estado, op('pp_800'));
    ok(r.estado.step === 'visita' && r.lead, '1.visita + lead guardado');
    ok(r.mensajes[r.mensajes.length - 1].tipo === 'lista', '1.presupuesto -> lista de visita');
    const visitFila = r.mensajes[r.mensajes.length - 1].filas.find((f) => f.id.startsWith('visit_'));
    r = P(r.estado, op(visitFila.id));
    ok(r.estado.step === 'despedida', '1.handoff -> despedida');
    ok(r.mensajes[0].tipo === 'cta' && /wa\.me/.test(r.mensajes[0].url), '1.boton CTA con link');
    ok(/coordinar una visita para .+ Muchas gracias/.test(decodeURIComponent(r.mensajes[0].url)), '1.prefill con depto');
    ok(r.mensajes.length === 2 && !/quedo a disposición/i.test(texto1(r)), '1.solo 2 msgs, sin "quedo a disposicion"');
    const r2 = P(r.estado, txt('gracias!'));
    ok(r2.estado.step === 'fin' && /Muchas gracias por tu tiempo/.test(texto1(r2)), '1.proximo msg -> despedida unica');
    const r3 = P(r2.estado, txt('ok dale'));
    ok(r3.mensajes.length === 0 && r3.estado.step === 'fin', '1.fin -> mensaje suelto = silencio');
    const r4 = P(r2.estado, txt('hola'));
    ok(r4.estado.step === 'zona_flow', '1.fin -> un saludo nuevo reinicia');
  }

  // ---------- 2. Multi-barrio por formulario ----------
  console.log('2) Multi-barrio formulario: Palermo + Recoleta');
  {
    let r = P({ step: 'zona_flow', zonas: [] }, flow(['z_palermo', 'z_recoleta']));
    ok(r.estado.step === 'ambientes' && r.estado.zonas.length === 2, '2.dos zonas');
  }

  // ---------- 3. Multi-barrio por texto ----------
  console.log('3) Multi-barrio texto: "busco en palermo y recoleta"');
  {
    let r = P({ step: 'zona_flow', zonas: [] }, txt('busco en palermo y recoleta'));
    ok(r.estado.step === 'ambientes' && r.estado.zonas.includes('z_palermo') && r.estado.zonas.includes('z_recoleta'), '3.dos zonas por texto');
  }

  // ---------- 4. Barrio inválido ----------
  console.log('4) Barrio inválido: "caballito"');
  {
    let r = P({ step: 'zona_flow', zonas: [] }, txt('caballito'));
    ok(r.estado.step === 'zona_flow' && /en cartera actualmente/.test(texto1(r)), '4.mensaje barrio invalido');
    ok(/Palermo.*Villa Crespo.*Almagro.*Centro.*Retiro.*Puerto Madero.*Zona Norte/.test(texto1(r)), '4.lista los 11 barrios');
  }

  // ---------- 5. Typos ----------
  console.log('5) Typos: palrmo / recoleeta / belgrno / nuñes');
  {
    ok(P({ step: 'zona_flow', zonas: [] }, txt('palrmo')).estado.zonas?.includes('z_palermo'), '5.palrmo->Palermo');
    ok(P({ step: 'zona_flow', zonas: [] }, txt('recoleeta')).estado.zonas?.includes('z_recoleta'), '5.recoleeta->Recoleta');
    ok(P({ step: 'zona_flow', zonas: [] }, txt('belgrno')).estado.zonas?.includes('z_belgrano'), '5.belgrno->Belgrano');
    ok(P({ step: 'zona_flow', zonas: [] }, txt('nuñes')).estado.zonas?.includes('z_nunez'), '5.nuñes->Núñez');
  }

  // ---------- 6. Sinónimos ----------
  console.log('6) Sinónimos: "las cañitas" / "soho" / "san isidro" / "olivos"');
  {
    ok(P({ step: 'zona_flow', zonas: [] }, txt('las cañitas')).estado.zonas?.includes('z_palermo'), '6.cañitas->Palermo');
    ok(P({ step: 'zona_flow', zonas: [] }, txt('soho')).estado.zonas?.includes('z_palermo'), '6.soho->Palermo');
    ok(P({ step: 'zona_flow', zonas: [] }, txt('san isidro')).estado.zonas?.includes('z_norte'), '6.san isidro->Zona Norte');
    ok(P({ step: 'zona_flow', zonas: [] }, txt('olivos')).estado.zonas?.includes('z_norte'), '6.olivos->Zona Norte');
  }

  // ---------- 7. Ambientes y presupuesto por texto ----------
  console.log('7) Ambientes/presupuesto escritos');
  {
    let r = P({ step: 'ambientes', zonas: ['z_palermo'] }, txt('dos ambientes'));
    ok(r.estado.step === 'tiempo' && r.estado.ambientes === 'amb_2', '7.dos->amb_2');
    r = P({ step: 'presupuesto', zonas: ['z_palermo'], ambientes: 'amb_1', timing: 't_ya' }, txt('como 1000 usd'));
    ok(r.estado.step === 'visita' || r.estado.step === 'pedir_contacto', '7.1000->tramo procesado');
  }

  // ---------- 8. Matching cruzado (Recoleta 1amb hasta 800 -> Palermo/Villa Crespo) ----------
  console.log('8) Matching cruzado: Recoleta 1amb hasta 800');
  {
    let est = { step: 'presupuesto', zonas: ['z_recoleta'], ambientes: 'amb_1', timing: 't_ya' };
    let r = P(est, op('pp_800'));
    ok(r.estado.step === 'visita', '8.llega a visita por cruzado');
    ok(/no tengo en ese presupuesto, pero te muestro/.test(texto1(r)), '8.mensaje cruzado');
    ok(r.mensajes.some((m) => m.tipo === 'imagen_caption'), '8.muestra fotos de las cruzadas');
    const slugs = r.estado.mostrados.map((m) => m.slug);
    ok(slugs.length > 0 && r.estado.mostrados.every((m) => m.slug), '8.tiene mostrados');
  }

  // ---------- 9. EL BUG REPORTADO: 3 amb hasta 800 NO debe dead-endear ----------
  console.log('9) 3 ambientes hasta 800: muestra el de 750/800 (no "no tengo")');
  {
    let est = { step: 'presupuesto', zonas: ['z_nunez'], ambientes: 'amb_3', timing: 't_ya' };
    let r = P(est, op('pp_800'));
    ok(r.estado.step === 'visita', '9.no dead-end -> visita');
    ok(/No tengo .*en ese presupuesto, te paso opciones que se ajustan a tus preferencias/.test(texto1(r)), '9.mensaje claro');
    ok(r.estado.mostrados.some((m) => m.slug === 'francisco-acuna-de-figueroa-1560-1g'), '9.incluye el de 750');
    ok(!/no tengo unidades disponibles a menos de 800/i.test(texto1(r)), '9.NO dice el mensaje viejo');
    const lista9 = r.mensajes[r.mensajes.length - 1];
    ok(/Tu presupuesto se adecúa a estas alternativas/.test(lista9.texto), '9.lista dice "estas alternativas" (no "lo que buscás")');
  }

  // ---------- 10. No me interesa -> web + contacto Tiziana (sin prefill) -> fin ----------
  console.log('10) "No me interesa" -> web + contacto Tiziana -> fin -> silencio');
  {
    let est = { step: 'visita', zonas: ['z_palermo'], ambientes: 'amb_1', mostrados: [{ slug: 'x', nombre: 'X', etiqueta: 'X' }] };
    let r = P(est, op('no_visita'));
    ok(r.estado.step === 'fin' && !r.usarIA, '10.fin sin IA');
    ok(/Te dejo nuestra web para que veas todas nuestras opciones/.test(r.mensajes[0].texto) && !/Saludos/.test(r.mensajes[0].texto), '10.msg web sin ¡Saludos!');
    const cta = r.mensajes.find((m) => m.tipo === 'cta');
    ok(cta && /Tiziana/.test(cta.texto) && cta.url === 'https://wa.me/5491123106629', '10.contacto Tiziana SIN prefill (?text)');
    ok(P(r.estado, txt('?')).mensajes.length === 0, '10.silencio despues');
  }

  // ---------- 11. "no" escrito en visita ----------
  console.log('11) "no gracias" escrito en visita');
  {
    let est = { step: 'visita', zonas: ['z_palermo'], ambientes: 'amb_1', mostrados: [{ slug: 'x', nombre: 'X', etiqueta: 'X' }] };
    ok(P(est, txt('no gracias')).estado.step === 'fin', '11.no escrito -> cierre web');
  }

  // ---------- 12. reiniciar desde cualquier punto ----------
  console.log('12) "reiniciar" desde el medio');
  {
    ok(P({ step: 'presupuesto', zonas: ['z_palermo'], ambientes: 'amb_2' }, txt('reiniciar')).estado.step === 'zona_flow', '12.reinicia');
    ok(P({ step: 'fin' }, txt('reiniciar')).estado.step === 'zona_flow', '12.reinicia hasta desde fin');
    ok(P({ step: 'fin' }, txt('hola')).estado.step === 'zona_flow', '12.un saludo reinicia desde fin');
    ok(P({ step: 'fin' }, txt('buenas tardes')).estado.step === 'zona_flow', '12.buenas reinicia');
    ok(P({ step: 'fin' }, txt('ok gracias')).mensajes.length === 0, '12.mensaje suelto en fin -> silencio');
    // "hola" en cualquier estado RE-SALUDA (2 mensajes), no lo toma como barrio inválido
    const rh = P({ step: 'zona_flow', zonas: [] }, txt('hola'));
    ok(rh.mensajes.length === 2 && /Te habla Tomás/.test(rh.mensajes[0].texto), '12.hola en zona_flow re-saluda (no "elegí barrio")');
    // pero "hola + barrio" NO reinicia: extrae el barrio
    ok(P({ step: 'zona_flow', zonas: [] }, txt('hola, busco en palermo')).estado.zonas?.includes('z_palermo'), '12.hola+barrio extrae el barrio');
    // "hola" en el medio del flujo también re-saluda
    ok(P({ step: 'presupuesto', zonas: ['z_palermo'], ambientes: 'amb_2' }, txt('hola!')).estado.step === 'zona_flow', '12.hola en el medio re-saluda');
  }

  // ---------- 13. Garbage / reintentos ----------
  console.log('13) Inputs basura -> reintento (no rompe)');
  {
    ok(/elegí una de las opciones/i.test(texto1(P({ step: 'ambientes', zonas: ['z_palermo'] }, txt('askjdh')))), '13.ambientes basura');
    ok(/elegí una de las opciones/i.test(texto1(P({ step: 'presupuesto', zonas: ['z_palermo'], ambientes: 'amb_1' }, txt('???')))), '13.presupuesto basura');
    ok(P({ step: 'zona_flow', zonas: [] }, txt('')).estado.step === 'zona_flow', '13.zona vacia no rompe');
    ok(P({ step: 'visita', mostrados: [] }, op('boton_raro')).estado.step === 'visita', '13.visita boton raro');
  }

  // ---------- 14. Recorrido por CADA barrio (que ninguno explote y muestre algo coherente) ----------
  console.log('14) Cada barrio x cada ambiente x cada presupuesto (sin crashear)');
  {
    const zonas = ['z_palermo', 'z_recoleta', 'z_belgrano', 'z_nunez', 'z_colegiales', 'z_villacrespo', 'z_almagro', 'z_centro', 'z_retiro', 'z_madero', 'z_norte'];
    const ambs = ['amb_1', 'amb_2', 'amb_3'];
    const presus = ['pp_800', 'pp_1500', 'pp_2500', 'pp_max'];
    let combos = 0, crashes = 0;
    for (const z of zonas) for (const a of ambs) for (const pp of presus) {
      combos++;
      try {
        let r = P({ step: 'presupuesto', zonas: [z], ambientes: a, timing: 't_ya' }, op(pp));
        const okStep = ['visita', 'pedir_contacto'].includes(r.estado.step);
        if (!okStep) { crashes++; console.log('   ⚠ combo raro', z, a, pp, '->', r.estado.step); }
      } catch (e) { crashes++; console.log('   💥 crash', z, a, pp, e.message); }
    }
    ok(crashes === 0, `14.${combos} combos sin crash`);
  }

  // ---------- 15. Los 4 barrios nuevos encuentran su depto ----------
  console.log('15) Barrios nuevos: Villa Crespo / Almagro / Centro / Retiro');
  {
    const casos = [
      ['z_villacrespo', 'amb_1', 'pp_800',  'Villa Crespo'],
      ['z_almagro',     'amb_3', 'pp_1500', 'Almagro'],
      ['z_centro',      'amb_3', 'pp_2500', 'Centro'],
      ['z_retiro',      'amb_3', 'pp_2500', 'Retiro'],
    ];
    for (const [z, a, pp, label] of casos) {
      const r = P({ step: 'presupuesto', zonas: [z], ambientes: a, timing: 't_ya' }, op(pp));
      ok(r.estado.step === 'visita' && (r.estado.mostrados || []).length > 0, `15.${label} muestra depto propio`);
    }
  }

  // ---------- 16. Texto de barrios nuevos ----------
  console.log('16) Texto: "villa crespo" / "almagro" / "centro" / "retiro"');
  {
    ok(P({ step: 'zona_flow', zonas: [] }, txt('villa crespo')).estado.zonas?.includes('z_villacrespo'), '16.villa crespo');
    ok(P({ step: 'zona_flow', zonas: [] }, txt('almagro')).estado.zonas?.includes('z_almagro'), '16.almagro');
    ok(P({ step: 'zona_flow', zonas: [] }, txt('centro')).estado.zonas?.includes('z_centro'), '16.centro');
    ok(P({ step: 'zona_flow', zonas: [] }, txt('retiro')).estado.zonas?.includes('z_retiro'), '16.retiro');
    // que "cuatro ambientes" NO se confunda con Centro (falso positivo de fuzzy)
    ok(!P({ step: 'zona_flow', zonas: [] }, txt('cuatro')).estado.zonas?.includes('z_centro'), '16.cuatro NO es Centro');
  }

  // ---------- 17. BARRIDO EXTREMO A EXTREMO: toda conversación termina bien ----------
  // Para cada (barrio x ambientes x presupuesto) x {coordina visita, no quiere}:
  // confirmar que SIEMPRE termina en Tiziana o en el mensaje de la web, sin IA, sin crash.
  console.log('17) Barrido completo: cada conversación termina en Tiziana o web (sin IA)');
  {
    const zonas = ['z_palermo', 'z_recoleta', 'z_belgrano', 'z_nunez', 'z_colegiales', 'z_villacrespo', 'z_almagro', 'z_centro', 'z_retiro', 'z_madero', 'z_norte'];
    const ambs = ['amb_1', 'amb_2', 'amb_3'];
    const presus = ['pp_800', 'pp_1500', 'pp_2500', 'pp_max'];

    function journey(z, a, pp, elegirVisita) {
      let r = P({}, txt('hola'));
      r = P(r.estado, flow([z]));
      if (r.estado.step !== 'ambientes') return { err: `no llegó a ambientes (${r.estado.step})` };
      r = P(r.estado, op(a));
      r = P(r.estado, op('t_ya'));
      if (r.estado.step !== 'presupuesto') return { err: `no llegó a presupuesto (${r.estado.step})` };
      r = P(r.estado, op(pp));
      if (r.usarIA) return { err: 'usó IA en presupuesto' };
      if (r.estado.step === 'fin') return { fin: 'web', usoIA: false }; // nada en budget (no pasa con data actual)
      if (r.estado.step !== 'visita') return { err: `tras presupuesto: ${r.estado.step}` };
      const lista = r.mensajes[r.mensajes.length - 1];
      if (lista.tipo !== 'lista') return { err: 'no hay lista de visita' };
      const fila = lista.filas.find((f) => f.id.startsWith('visit_'));
      if (!fila) return { err: 'sin opción de visita' };

      if (elegirVisita) {
        r = P(r.estado, op(fila.id));
        const cta = r.mensajes.find((m) => m.tipo === 'cta');
        if (r.estado.step !== 'despedida' || !cta || !/wa\.me/.test(cta.url || '')) return { err: 'handoff mal' };
        if (r.usarIA) return { err: 'IA en handoff' };
        let r2 = P(r.estado, txt('una pregunta'));
        if (r2.estado.step !== 'fin' || !/Muchas gracias por tu tiempo/.test(texto1(r2)) || r2.usarIA) return { err: 'despedida mal' };
        if (P(r2.estado, txt('ok dale')).mensajes.length !== 0) return { err: 'no silencia tras fin' };
        return { fin: 'tiziana', usoIA: false };
      } else {
        r = P(r.estado, op('no_visita'));
        const ctaW = r.mensajes.find((m) => m.tipo === 'cta');
        if (r.estado.step !== 'fin' || !/Te dejo nuestra web/.test(texto1(r)) || !ctaW || r.usarIA) return { err: 'no_visita mal' };
        if (P(r.estado, txt('ok dale')).mensajes.length !== 0) return { err: 'no silencia tras no_visita' };
        return { fin: 'web', usoIA: false };
      }
    }

    let total = 0, tiziana = 0, web = 0, errores = 0, conIA = 0;
    for (const z of zonas) for (const a of ambs) for (const pp of presus) for (const elegir of [true, false]) {
      total++;
      let res;
      try { res = journey(z, a, pp, elegir); }
      catch (e) { errores++; console.log(`   💥 crash ${z}/${a}/${pp}/${elegir}: ${e.message}`); continue; }
      if (res.err) { errores++; console.log(`   ❌ ${z}/${a}/${pp}/visita=${elegir}: ${res.err}`); continue; }
      if (res.usoIA) conIA++;
      if (res.fin === 'tiziana') tiziana++;
      else if (res.fin === 'web') web++;
      else { errores++; console.log(`   ❌ ${z}/${a}/${pp}: fin desconocido`); }
    }
    console.log(`   -> ${total} conversaciones: ${tiziana} terminan en Tiziana, ${web} en web, ${conIA} usaron IA, ${errores} errores`);
    ok(errores === 0, `17.${total} conversaciones sin error`);
    ok(conIA === 0, '17.ninguna usó IA (todo gratis)');
    ok(tiziana + web === total, '17.TODAS terminan en Tiziana o web');
  }

  // ---------- 18. Precios: temporal (negrita + Todo incluido) | tradicional (negrita + expensas) ----------
  console.log('18) Temporal: negrita + Todo incluido | Tradicional: negrita + expensas');
  {
    const cap = (msgs, nombre) => { const m = msgs.find((x) => (x.caption || x.texto || '').includes(nombre)); return m ? (m.caption || m.texto) : ''; };
    // Fotos en el paso tiempo (con sus captions).
    const t = cap(P({ step: 'tiempo', zonas: ['z_palermo'], ambientes: 'amb_2' }, op('t_ya')).mensajes, 'Bonpland');
    ok(/\*USD 1\.000\/mes\*/.test(t), '18.temporal precio en *negrita*');
    ok(/\*\(Todo incluido: Alquiler \+ expensas \+ gastos\)\*/.test(t), '18.temporal "Todo incluido" en negrita');
    const t2 = cap(P({ step: 'tiempo', zonas: ['z_belgrano'], ambientes: 'amb_2' }, op('t_ya')).mensajes, 'Congreso');
    ok(/\*USD 950\/mes \+ expensas\*/.test(t2), '18.tradicional precio en *negrita* + expensas');
  }

  // ---------- 19. Las Cañitas = Palermo Y Belgrano; el paso tiempo muestra TODAS con foto ----------
  console.log('19) Las Cañitas = Palermo y Belgrano; tiempo muestra TODAS con foto');
  {
    const caps = (r) => r.mensajes.filter((m) => m.tipo === 'imagen_caption').map((m) => m.caption).join(' || ');
    ok(/Migueletes/.test(caps(P({ step: 'tiempo', zonas: ['z_belgrano'], ambientes: 'amb_2' }, op('t_ya')))), '19.Migueletes (Las Cañitas) aparece en Belgrano');
    ok(/Migueletes/.test(caps(P({ step: 'tiempo', zonas: ['z_palermo'], ambientes: 'amb_2' }, op('t_ya')))), '19.Migueletes (Las Cañitas) aparece en Palermo');
    // Caso del usuario: Palermo+Belgrano+Núñez 2amb -> incluye Lavalle (antes se cortaba en 3)
    const c = caps(P({ step: 'tiempo', zonas: ['z_palermo', 'z_belgrano', 'z_nunez'], ambientes: 'amb_2' }, op('t_ya')));
    ok(/Congreso/.test(c) && /Bonpland/.test(c) && /Migueletes/.test(c) && /Lavalle/.test(c), '19.muestra TODAS con foto (incluye Lavalle)');
  }

  // ---------- 20. Activación: primer mensaje cualquiera saluda; en fin solo "hola"/"buenas" ----------
  console.log('20) Activación: primer mensaje cualquiera saluda; en fin solo "hola"/"buenas"');
  {
    ok(P({}, txt('me interesa un depto en palermo')).estado.step === 'zona_flow', '20.primer msg cualquiera -> saluda');
    ok(P({}, { tipo: 'otro', texto: '' }).estado.step === 'zona_flow', '20.primer msg foto/audio -> saluda');
    ok(P({ step: 'fin' }, txt('hola, quiero ver otro depto')).estado.step === 'zona_flow', '20.fin + "hola..." reactiva');
    ok(P({ step: 'fin' }, txt('buenas, algo mas?')).estado.step === 'zona_flow', '20.fin + "buenas..." reactiva');
    ok(P({ step: 'fin' }, txt('gracias por todo')).mensajes.length === 0, '20.fin + msg sin saludo = silencio');
    ok(P({ step: 'fin' }, { tipo: 'otro', texto: '' }).mensajes.length === 0, '20.fin + foto/audio = silencio');
  }

  console.log('\n=========================================');
  console.log(`RESULTADO: ${PASS} OK, ${FAIL} fallas`);
  console.log('=========================================');
  process.exit(FAIL ? 1 : 0);
})().catch((e) => { console.error('ERR', e); process.exit(1); });
